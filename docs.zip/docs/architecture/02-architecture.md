---
sidebar_position: 2
---

# Огляд архітектури
> Див. також [Платформа](architecture/04-platform.md) та [Контракти](contracts/05-contracts.md)

## Основні компоненти вузла (Node)

У DNIP кожен вузол описується п’ятьма ключовими артефактами.  
Вони працюють разом і утворюють єдину архітектуру.

---

### 1. **protocol.json**
- Декларація сервісів, дій, gateway, cron та processors.  
- Це ядро вузла: воно визначає **що вузол вміє робити**.  
- `services` → опис дій (actions) та їхніх контрактів.  
- `gateway` → мапінг HTTP маршрутів і Events на дії.  
- `cron` → періодичні завдання.  
- `processors` → відтерміновані завдання.  

---

### 2. **contracts/*.json**
- Кожна дія (action) має свій контракт.  
- Формат: **[JSON Schema draft-07](https://json-schema.org/draft-07/draft-handrews-json-schema-01)**.
- Контракти описують `headers`, `input`, `output`.  
- Усі контракти зберігаються у **плоскій структурі** `contracts/*.json` без піддиректорій.  
- Це формальна обіцянка вузла на правильний формат даних.

---

### 3. **config.js**
- Конфігурація вузла.  
- Визначає параметри оточення:  
  - підключення до баз даних, кешів, сторонніх API;  
  - параметри gateway (host/port, TLS, CORS);  
  - налаштування черг (processors).  
- Використовується у `adapters.js`, щоб створювати інстанси клієнтів.  

---

### 4. **adapters.js**
- Реалізація адаптерів на основі `config.js`.  
- Повертає готові клієнти для роботи з інфраструктурними сервісами (Postgres, Redis, Kafka, AMQP, Mailer тощо).  
- Робить їх доступними через `context.adapters` у `protocol.js`.  
- Забезпечує відокремлення бізнес-логіки від деталей підключення.  

---

### 5. **protocol.js**
- Реалізація логіки вузла.  
- Містить функції для `domain`, cronjobs, processors.  
- Саме тут описано **як** виконуються дії, визначені у `protocol.json`.  
- Використовується підхід:  

```js
export default function ProtocolImplementation() {
  return {
    domain: {
      system: {
        ping: async (params, context) => {
          const db = context.adapters.postgres;
          const res = await db.query("SELECT 1 as ok");
          return { echo: params.message, db: res.rows[0].ok };
        }
      }
    }
  };
}
```

---

## Структура вузла

```
.
├── contracts/
│   └── *.json        ← контракти (JSON Schema)
├── protocol.json     ← декларація вузла
├── config.js         ← конфігурація
├── adapters.js       ← інстанси клієнтів (БД, кеш та інші ресурси)
└── protocol.js       ← реалізація логіки
```

---

## Як це працює разом

1. **protocol.json** описує, які дії доступні.  
2. **contracts/*.json** гарантують формат даних для цих дій.  
3. **config.js** описує параметри доступу до ресурсів.  
4. **adapters.js** створює клієнти зовнішних ресурвів та передає їх у `context.adapters`.  
5. **protocol.js** реалізує логіку дій, використовуючи контракти і адаптери.  

У результаті кожен вузол DNIP прозорий: його можливості можна зрозуміти, просто подивившись у `protocol.json` і відповідні контракти, а реалізацію легко протестувати через чітко визначені адаптери.